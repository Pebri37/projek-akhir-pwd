<?php
// Test script untuk chapter upload
include 'includes/koneksi.php';

echo "<h2>Test Database Connection</h2>";

// Test connection
if ($conn) {
    echo "✅ Database connection successful<br>";
} else {
    echo "❌ Database connection failed<br>";
    exit;
}

// Test komik table
$komik_test = mysqli_query($conn, "SELECT * FROM komik LIMIT 1");
if ($komik_test && mysqli_num_rows($komik_test) > 0) {
    echo "✅ Komik table accessible<br>";
    $komik = mysqli_fetch_assoc($komik_test);
    echo "Sample komik: " . $komik['judul'] . " (ID: " . $komik['id'] . ")<br>";
} else {
    echo "❌ No komik data found or table inaccessible<br>";
}

// Test chapter table
$chapter_test = mysqli_query($conn, "SELECT * FROM chapter LIMIT 1");
if ($chapter_test) {
    echo "✅ Chapter table accessible<br>";
    echo "Chapter count: " . mysqli_num_rows($chapter_test) . "<br>";
} else {
    echo "❌ Chapter table error: " . mysqli_error($conn) . "<br>";
}

// Test upload directory
$upload_dir = 'upload/chapter/';
if (!is_dir($upload_dir)) {
    if (mkdir($upload_dir, 0777, true)) {
        echo "✅ Upload directory created<br>";
    } else {
        echo "❌ Failed to create upload directory<br>";
    }
} else {
    echo "✅ Upload directory exists<br>";
}

// Check directory permissions
if (is_writable($upload_dir)) {
    echo "✅ Upload directory is writable<br>";
} else {
    echo "❌ Upload directory is not writable<br>";
}

echo "<h2>Test Form</h2>";
echo '<form action="author/upload-chapter.php?komik_id=1" method="GET">';
echo '<button type="submit">Go to Upload Chapter Page</button>';
echo '</form>';
?>
