<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<header>
    <div class="navbar-container">
        <nav>
            <div class="logo">
                <a href="/index.php"><img src="/praktikumPwd/ProjekAkhir/asset/logo.png" alt="logo" width="100px" /></a>
            </div>
            <div class="nav-list">
                <ul>
                    <li><a href="/praktikumPwd/ProjekAkhir/index.php">Home</a></li>
                    <li><a href="/praktikumPwd/ProjekAkhir/pages/genre.php">Genre</a></li>
                    <li><a href="/praktikumPwd/ProjekAkhir/pages/populer.php">Populer</a></li>
                    <li><a href="/praktikumPwd/ProjekAkhir/pages/kanvas.php">Kanvas</a></li>
                </ul>
            </div>

            <div class="right-list">
                <ul>
                    <?php if (isset($_SESSION['user_nama'])): ?>
                        <select id="daftar-role" class="dropdown-daftar" style="margin-left: 5rem;">
                            <option selected hidden>👤 <?= htmlspecialchars($_SESSION['user_nama']) ?></option>

                            <?php if ($_SESSION['user_role'] === 'author'): ?>
                                <option value="/praktikumPwd/ProjekAkhir/author/dashboard.php">Dashboard</option>
                            <?php elseif ($_SESSION['user_role'] === 'pembaca'): ?>
                                <option value="/praktikumPwd/ProjekAkhir/user/profile.php">Profil</option>
                            <?php endif; ?>

                            <option value="auth/logout.php">Logout</option>
                        </select>
                    <?php else: ?>
                        <li><a href="auth/login.php">Masuk</a></li>
                        <select id="daftar-role" class="dropdown-daftar">
                            <option selected hidden>Daftar</option>
                            <option value="auth/daftarpembaca.php">Pembaca</option>
                            <option value="auth/daftarauthor.php">Author</option>
                        </select>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </div>
</header>