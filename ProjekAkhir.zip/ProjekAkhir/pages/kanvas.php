<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Genre</title>
    <link rel="stylesheet" href="../css/style.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT"
      crossorigin="anonymous"
    />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
  </head>
  <body>
    <?php include '../includes/header.php'; ?>

    <main>
      <!-- Navbar Genre -->
      <nav class="jenre-navbar">
        <ul>
          <li class="active">HOME</li>
          <li>ROMANTIS</li>
          <li>AKSI</li>
          <li>HOROR</li>
          <li>FANTASI</li>
        </ul>
      </nav>

      <!-- Info Banner -->
      <div class="canvas-banner">
        <p>
          <img src="../asset/logo.png" alt="icon" width="20" /> Temukan beragam
          karya di <b>KANVAS</b>, platform penerbitan mandiri untuk kreator
        </p>
      </div>

      <!-- Section Rekomendasi -->
      <section class="canvas-section">
        <h2>Rekomendasi</h2>

        <div class="canvas-list">
          <!-- Card 1 -->
          <div class="canvas-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="BOLOZ"
            />
            <div class="canvas-overlay">
              <span class="views">4RB</span>
              <span class="jenre">horor</span>
              <h3>BOLOZ</h3>
              <p>Tiannxx__</p>
            </div>
          </div>

          <!-- Card 2 -->
          <div class="canvas-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Gloomy"
            />
            <div class="canvas-overlay">
              <span class="views">33RB</span>
              <span class="jenre">romantis</span>
              <h3>My Gloomy Husband</h3>
              <p>Simelone</p>
            </div>
          </div>

          <!-- Card 3 -->
          <div class="canvas-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Lucky"
            />
            <div class="canvas-overlay">
              <span class="views">2RB</span>
              <span class="jenre">romantis</span>
              <h3>LUCKY PRETENDER</h3>
              <p>maidraw</p>
            </div>
          </div>

          <!-- Card 4 -->
          <div class="canvas-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Stereotype"
            />
            <div class="canvas-overlay">
              <span class="views">3RB</span>
              <span class="jenre">drama</span>
              <h3>Stereotype</h3>
              <p>5unn</p>
            </div>
          </div>

          <!-- Card 5 -->
          <div class="canvas-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Bunny"
            />
            <div class="canvas-overlay">
              <span class="views">2RB</span>
              <span class="jenre">drama</span>
              <h3>Bunny's Home</h3>
              <p>nann.pit</p>
            </div>
          </div>
        </div>
      </section>

      <section class="kanvas-banner-full">
        <div class="banner-content">
          <div class="banner-text">
            <h2>Kembangkan karyamu di <span>KOMIKKITA KANVAS</span></h2>
            <a href="#" class="btn-mulai">Mulai sekarang &rsaquo;</a>
          </div>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <div class="footer-logo">
        <img src="../asset/logo.png" alt="logo-footer" />
      </div>
      <p class="copyright">Copyright @ Komikita id. All right reserved.</p>
      <div class="footer-links">
        <a href="#">Baca Komik</a> | <a href="#">Baca Manga</a> |
        <a href="#">Baca Manhwa</a> | <a href="#">Baca Manhua</a> |
        <a href="#">DMCA</a> | <a href="#">Terms of Usage</a> |
        <a href="#">Privacy Policy</a> |
        <a href="#">Contact Us</a>
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
      crossorigin="anonymous"
    ></script>

    <script src="../js/script.js"></script>
  </body>
</html>
