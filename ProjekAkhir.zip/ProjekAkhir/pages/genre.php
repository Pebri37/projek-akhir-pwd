<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Genre</title>
    <link rel="stylesheet" href="../css/style.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT"
      crossorigin="anonymous"
    />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
  </head>
  <body>
    <?php include '../includes/header.php'; ?>

    <main>
      <div class="genre-filter">
        <ul>
          <li class="active">Drama</li>
          <li>Romantis</li>
          <li>Aksi</li>
          <li>Horor</li>
          <li>Fantasi</li>
        </ul>
      </div>

      <section class="komik-genre-list">
        <h3>DRAMA</h3>

        <div class="komik-row">
          <div class="komik-cover">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Oh! Dangun"
            />
            <span class="label-up">UP 9</span>
            <span class="label-genre">Manhwa Drama</span>
          </div>

          <div class="komik-info">
            <h4>Oh! Dangun</h4>
            <p class="komik-stats">336rb x · 2 jam · Berwarna</p>
            <p class="komik-desc">
              Ada hewan-hewan yang ditelantarkan oleh Dangun dan hidup secara
              rahasia di dunia manusia. Narae, seorang siswa SMA biasa~
            </p>
            <div class="chapter-buttons">
              <span class="btn-chapter">Awal: <b>Chapter 01</b></span>
              <span class="btn-chapter">Terbaru: <b>Chapter 70</b></span>
            </div>
          </div>
        </div>

        <h3>ROMANTIS</h3>
        <div class="komik-row">
          <div class="komik-cover">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Tales of Demons"
            />
            <span class="label-up">UP 3</span>
            <span class="label-genre">Manhwa Romantis</span>
          </div>

          <div class="komik-info">
            <h4>Tales of Demons and Gods</h4>
            <p class="komik-stats">31.7jt x · 2 jam · Berwarna</p>
            <p class="komik-desc">
              Nie Lie menggunakan pengetahuan masa lalunya untuk bertahan hidup,
              menyelamatkan dunia dan orang-orang yang dicintainya dari~
            </p>
            <div class="chapter-buttons">
              <span class="btn-chapter">Awal: <b>Chapter 1</b></span>
              <span class="btn-chapter">Terbaru: <b>Chapter 497</b></span>
            </div>
          </div>
        </div>

        <h3>AKSI</h3>
        <div class="komik-row">
          <div class="komik-cover">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Tales of Demons"
            />
            <span class="label-up">UP 3</span>
            <span class="label-genre">Manhwa Romantis</span>
          </div>

          <div class="komik-info">
            <h4>Tales of Demons and Gods</h4>
            <p class="komik-stats">31.7jt x · 2 jam · Berwarna</p>
            <p class="komik-desc">
              Nie Lie menggunakan pengetahuan masa lalunya untuk bertahan hidup,
              menyelamatkan dunia dan orang-orang yang dicintainya dari~
            </p>
            <div class="chapter-buttons">
              <span class="btn-chapter">Awal: <b>Chapter 1</b></span>
              <span class="btn-chapter">Terbaru: <b>Chapter 497</b></span>
            </div>
          </div>
        </div>

        <h3>HOROR</h3>
        <div class="komik-row">
          <div class="komik-cover">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Tales of Demons"
            />
            <span class="label-up">UP 3</span>
            <span class="label-genre">Manhwa Romantis</span>
          </div>

          <div class="komik-info">
            <h4>Tales of Demons and Gods</h4>
            <p class="komik-stats">31.7jt x · 2 jam · Berwarna</p>
            <p class="komik-desc">
              Nie Lie menggunakan pengetahuan masa lalunya untuk bertahan hidup,
              menyelamatkan dunia dan orang-orang yang dicintainya dari~
            </p>
            <div class="chapter-buttons">
              <span class="btn-chapter">Awal: <b>Chapter 1</b></span>
              <span class="btn-chapter">Terbaru: <b>Chapter 497</b></span>
            </div>
          </div>
        </div>

        <h3>FANTASI</h3>
        <div class="komik-row">
          <div class="komik-cover">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Tales of Demons"
            />
            <span class="label-up">UP 3</span>
            <span class="label-genre">Manhwa Romantis</span>
          </div>

          <div class="komik-info">
            <h4>Tales of Demons and Gods</h4>
            <p class="komik-stats">31.7jt x · 2 jam · Berwarna</p>
            <p class="komik-desc">
              Nie Lie menggunakan pengetahuan masa lalunya untuk bertahan hidup,
              menyelamatkan dunia dan orang-orang yang dicintainya dari~
            </p>
            <div class="chapter-buttons">
              <span class="btn-chapter">Awal: <b>Chapter 1</b></span>
              <span class="btn-chapter">Terbaru: <b>Chapter 497</b></span>
            </div>
          </div>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <div class="footer-logo">
        <img src="../asset/logo.png" alt="logo-footer" />
      </div>
      <p class="copyright">Copyright @ Komikita id. All right reserved.</p>
      <div class="footer-links">
        <a href="#">Baca Komik</a> | <a href="#">Baca Manga</a> |
        <a href="#">Baca Manhwa</a> | <a href="#">Baca Manhua</a> |
        <a href="#">DMCA</a> | <a href="#">Terms of Usage</a> |
        <a href="#">Privacy Policy</a> |
        <a href="#">Contact Us</a>
      </div>
    </footer>


    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
      crossorigin="anonymous"
    ></script>

    <script src="js/script.js"></script>
  </body>
</html>
