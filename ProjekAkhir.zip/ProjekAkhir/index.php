<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Beranda</title>
  <link rel="stylesheet" href="css/style.css" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT"
    crossorigin="anonymous" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet" />
</head>

<body>
  <?php include 'includes/header.php'; ?>

  <main>
    <div class="content">
      <div class="background">
        <img
          src="asset/bg.jpg"
          alt="bg"
          width="100%"
          height="auto"
          object-fit="cover"
          style="z-index: 999" />
        <img
          src="asset/naruto.png"
          alt="bg-n"
          class="naruto"
          width="50%"
          height="auto"
          object-fit="cover" />
      </div>
    </div>

    <div class="container">
      <div class="card">
        <section class="populer">
          <h1>Populer</h1>
          <div class="row">
            <div class="col-3">
              <img
                src="https://cover.komiku.id/wp-content/uploads/2020/07/Komik-Salaryman-Ga-Isekai-Ni-Ittara-Shitennou-Ni-Natta-Hanashi.jpg?resize=240,150"
                alt="populer"
                width="100%"
                height="auto"
                object-fit="cover" />
              <p>
                Solo Leveling: Ragnarok <br /><span style="display: tra">Fantasi</span>
              </p>
              <div class="chapternow">
                <p>Chapter 1</p>
              </div>
            </div>
            <div class="col-3">
              <img
                src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
                alt="populer"
                width="100%"
                height="auto"
                object-fit="cover" />
              <p>
                Solo Leveling: Ragnarok <br /><span style="display: tra">Fantasi</span>
              </p>
              <div class="chapternow">
                <p>Chapter 1</p>
              </div>
            </div>
            <div class="col-3">
              <img
                src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
                alt="populer"
                width="100%"
                height="auto"
                object-fit="cover" />
              <p>
                Solo Leveling: Ragnarok <br /><span style="display: tra">Fantasi</span>
              </p>
              <div class="chapternow">
                <p>Chapter 1</p>
              </div>
            </div>
            <div class="col-3">
              <img
                src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
                alt="populer"
                width="100%"
                height="auto"
                object-fit="cover" />
              <p>
                Solo Leveling: Ragnarok <br /><span style="display: tra">Fantasi</span>
              </p>
              <div class="chapternow">
                <p>Chapter 1</p>
              </div>
            </div>
          </div>
        </section>
      </div>

      <section class="terbaru">
        <h2 style="text-align: center">
          Baca Komik <span class="highlight">Terbaru</span>
        </h2>
        <div class="comic-list">
          <div class="comic-card">
            <img
              src="https://cover.komiku.id/wp-content/uploads/2020/07/Komik-Salaryman-Ga-Isekai-Ni-Ittara-Shitennou-Ni-Natta-Hanashi.jpg?resize=240,150"
              alt="Cover Komik" />
            <div class="comic-info">
              <h3>Solo Leveling: Ragnarok</h3>
              <p class="genre">Manhwa Fantasi 3 jam lalu</p>
              <button class="chapter-btn">Chapter 1</button>
            </div>
          </div>

          <div class="comic-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Cover Komik" />
            <div class="comic-info">
              <h3>Dr. Stone</h3>
              <p class="genre">Manga Petualangan 3 jam lalu</p>
              <button class="chapter-btn">Chapter 230</button>
            </div>
          </div>

          <div class="comic-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Cover Komik" />
            <div class="comic-info">
              <h3>Dr. Stone</h3>
              <p class="genre">Manga Petualangan 3 jam lalu</p>
              <button class="chapter-btn">Chapter 230</button>
            </div>
          </div>

          <div class="comic-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="Cover Komik" />
            <div class="comic-info">
              <h3>Dr. Stone</h3>
              <p class="genre">Manga Petualangan 3 jam lalu</p>
              <button class="chapter-btn">Chapter 230</button>
            </div>
          </div>
        </div>
      </section>

      <section class="kanvas-section">
        <div class="kanvas-info">
          <h2>KANVAS</h2>
          <p>
            Temukan beragam karya di KANVAS, platform penerbitan mandiri untuk
            kreator indie
          </p>
          <a href="#" class="kanvas-button">Ke KANVAS</a>
        </div>

        <div class="kanvas-gallery">
          <div class="kn-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="MANIS" />
            <div class="kn-info">
              <h4>MANIS</h4>
              <span>PUCUK FLY</span>
            </div>
          </div>

          <div class="kn-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="A Shelter for..." />
            <div class="kn-info">
              <h4>A Shelter fo...</h4>
              <span>chirailyn</span>
            </div>
          </div>

          <div class="kn-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="A Shelter for..." />
            <div class="kn-info">
              <h4>A Shelter fo...</h4>
              <span>chirailyn</span>
            </div>
          </div>

          <div class="kn-card">
            <img
              src="https://thumbnail.komiku.id/uploads/manga/komik-one-piece-indo/manga_thumbnail-Komik-One-Piece.jpg?resize=240,150"
              alt="A Shelter for..." />
            <div class="kn-info">
              <h4>A Shelter fo...</h4>
              <span>chirailyn</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  </main>

  <footer class="site-footer">
    <div class="footer-logo">
      <img src="asset/logo.png" alt="logo-footer" />
    </div>
    <p class="copyright">Copyright @ Komikita id. All right reserved.</p>
    <div class="footer-links">
      <a href="#">Baca Komik</a> | <a href="#">Baca Manga</a> |
      <a href="#">Baca Manhwa</a> | <a href="#">Baca Manhua</a> |
      <a href="#">DMCA</a> | <a href="#">Terms of Usage</a> |
      <a href="#">Privacy Policy</a> |
      <a href="#">Contact Us</a>
    </div>
  </footer>

  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
    crossorigin="anonymous"></script>

  <script src="js/script.js"></script>
</body>

</html>