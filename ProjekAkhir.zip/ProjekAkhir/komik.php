<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'includes/koneksi.php';

if (!isset($_GET['id'])) {
    echo "ID komik tidak ditemukan.";
    exit;
}

$id = intval($_GET['id']);
$query = mysqli_query($conn, "SELECT * FROM komik WHERE id = $id");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "Komik tidak ditemukan.";
    exit;
}

// Ambil semua chapter
$chapter_result = mysqli_query($conn, "SELECT * FROM chapter WHERE id_komik = $id ORDER BY urutan ASC");
?>

<?php include 'includes/header.php'; ?>
<div class="container" style="padding: 2rem;">
    <h1><?= htmlspecialchars($data['judul']) ?></h1>
    <img src="upload/<?= htmlspecialchars($data['cover']) ?>" width="250px" style="border-radius: 8px;">
    <p><strong>Genre:</strong> <?= htmlspecialchars($data['genre']) ?></p>
    <p><?= nl2br(htmlspecialchars($data['deskripsi'])) ?></p>

    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'author' && $_SESSION['user_id'] == $data['user_id']): ?>
        <a href="author/upload-chapter.php?komik_id=<?= $data['id'] ?>" class="btn btn-primary">Tambah Chapter</a>
    <?php endif; ?>

    <hr>
    <h3>Daftar Chapter</h3>
    <ul>
        <?php while ($chap = mysqli_fetch_assoc($chapter_result)): ?>
            <li>
                <a href="chapter.php?komik_id=<?= $id ?>&chapter=<?= $chap['urutan'] ?>">
                    <?= htmlspecialchars($chap['judul']) ?>
                </a>
            </li>
        <?php endwhile; ?>
    </ul>
</div>