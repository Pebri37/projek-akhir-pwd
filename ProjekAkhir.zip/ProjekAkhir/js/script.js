document.addEventListener("DOMContentLoaded", function () {
  const daftarSelect = document.getElementById("daftar-role");
  daftarSelect.addEventListener("change", function () {
    const selected = this.value;
    if (selected) {
      window.location.href = selected;
    }
  });
});

document.getElementById('daftar-role').addEventListener('change', function () {
  window.location.href = this.value;
}); // ini buat login di navbar
