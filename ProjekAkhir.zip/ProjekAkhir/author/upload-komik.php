<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'author') {
    header("Location: ../index.php");
    exit;
}

include '../includes/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $genre = mysqli_real_escape_string($conn, $_POST['genre']);
    $user_id = $_SESSION['user_id'];

    // Validasi file
    if ($_FILES['cover']['error'] === 0) {
        $cover = $_FILES['cover']['name'];
        $tmp = $_FILES['cover']['tmp_name'];

        // Rename file agar unik (biar ga ketiban)
        $ext = pathinfo($cover, PATHINFO_EXTENSION);
        $newName = uniqid() . '.' . $ext;
        $uploadPath = '../upload/' . $newName;

        if (move_uploaded_file($tmp, $uploadPath)) {
            // Simpan data ke DB
            $query = "INSERT INTO komik (judul, deskripsi, genre, cover, user_id)
                VALUES ('$judul', '$deskripsi', '$genre', '$newName', '$user_id')";
            $result = mysqli_query($conn, $query);

            if ($result) {
                header("Location: dashboard.php?success=1");
                exit;
            } else {
                $error = "Gagal menyimpan komik: " . mysqli_error($conn);
            }
        } else {
            $error = "Gagal upload cover!";
        }
    } else {
        $error = "Cover harus diunggah!";
    }
}
?>

<?php include '../includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Komik Baru</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f6fa;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .upload-komik-container {
            max-width: 480px;
            margin: 40px auto 0 auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            padding: 2.5rem 2.2rem 2rem 2.2rem;
        }
        .upload-komik-container h2 {
            text-align: center;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: #222;
        }
        .upload-komik-container label {
            font-weight: 500;
            color: #333;
        }
        .upload-komik-container input[type="text"],
        .upload-komik-container textarea {
            width: 100%;
            padding: 0.6rem 0.8rem;
            margin-top: 0.2rem;
            margin-bottom: 1.2rem;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1rem;
            background: #f9f9f9;
            transition: border 0.2s;
        }
        .upload-komik-container input[type="text"]:focus,
        .upload-komik-container textarea:focus {
            border: 1.5px solid #007bff;
            outline: none;
            background: #fff;
        }
        .upload-komik-container input[type="file"] {
            margin-bottom: 1.2rem;
        }
        .upload-komik-container button[type="submit"] {
            background: #222;
            color: #fff;
            border: none;
            padding: 0.6rem 1.5rem;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
            width: 100%;
        }
        .upload-komik-container button[type="submit"]:hover {
            background: #007bff;
        }
        .upload-komik-container .alert {
            text-align: center;
            margin-bottom: 1.2rem;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <div class="upload-komik-container">
        <h2>Tambah Komik Baru</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <label>Judul Komik</label>
            <input type="text" name="judul" required>

            <label>Deskripsi</label>
            <textarea name="deskripsi" rows="4" required></textarea>

            <label>Genre</label>
            <input type="text" name="genre" required>

            <label>Upload Cover</label>
            <input type="file" name="cover" accept="image/*" required>

            <button type="submit">Upload Komik</button>
        </form>
    </div>
</body>
</html>