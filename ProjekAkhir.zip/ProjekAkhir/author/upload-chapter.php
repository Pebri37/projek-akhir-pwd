<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../includes/koneksi.php';

// Cek login & role
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'author') {
    header("Location: ../auth/login.php");
    exit;
}

$komik_id = isset($_GET['komik_id']) ? intval($_GET['komik_id']) : 0;

// Cek apakah komik ini milik author
$cek = mysqli_query($conn, "SELECT * FROM komik WHERE id = $komik_id AND user_id = " . $_SESSION['user_id']);
$komik = mysqli_fetch_assoc($cek);
if (!$komik) {
    echo "Komik tidak ditemukan atau bukan milik kamu!";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul_chapter = mysqli_real_escape_string($conn, $_POST['judul']);
    $urutan = intval($_POST['urutan']);

    // Validasi input
    if (empty($judul_chapter)) {
        $error = "Judul chapter tidak boleh kosong!";
    } elseif ($urutan <= 0) {
        $error = "Urutan harus berupa angka positif!";
    } elseif (!isset($_FILES['file']) || $_FILES['file']['error'] !== 0) {
        $error = "File gambar harus diupload!";
    } else {
        // Cek apakah urutan sudah ada
        $cek_urutan = mysqli_query($conn, "SELECT id FROM chapter WHERE id_komik = $komik_id AND urutan = $urutan");
        if (mysqli_num_rows($cek_urutan) > 0) {
            $error = "Urutan chapter $urutan sudah ada! Pilih urutan yang lain.";        } else {
            // Validasi file upload
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $fileName = $_FILES['file']['name'];
            $tmp = $_FILES['file']['tmp_name'];
            $fileSize = $_FILES['file']['size'];
            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            
            // Validasi ukuran file (max 2MB)
            $maxSize = 2 * 1024 * 1024; // 2MB
            if ($fileSize > $maxSize) {
                $error = "Ukuran file terlalu besar! Maksimal 2MB.";
            }
            // Validasi ekstensi file
            elseif (!in_array($ext, $allowed_extensions)) {
                $error = "Format file tidak didukung! Gunakan: " . implode(', ', $allowed_extensions);
            } else {
                $newName = uniqid() . '.' . $ext;
                $folder = '../upload/chapter/';
                
                // Buat folder jika belum ada
                if (!is_dir($folder)) {
                    mkdir($folder, 0777, true);
                }
                
                $uploadPath = $folder . $newName;

                if (move_uploaded_file($tmp, $uploadPath)) {
                    // Insert ke database
                    $query = "INSERT INTO chapter (id_komik, judul_chapter, file_path, urutan) 
                        VALUES ($komik_id, '$judul_chapter', '$newName', $urutan)";
                    $result = mysqli_query($conn, $query);
                    
                    if ($result) {
                        $_SESSION['success'] = "Chapter berhasil diupload!";
                        header("Location: ../komik.php?id=$komik_id");
                        exit;
                    } else {
                        $error = "Gagal menyimpan chapter ke database: " . mysqli_error($conn);
                        // Hapus file yang sudah diupload jika gagal simpan ke database
                        if (file_exists($uploadPath)) {
                            unlink($uploadPath);
                        }
                    }
                } else {
                    $error = "Gagal upload gambar. Periksa permission folder upload.";
                }
            }
        }
    }
}
?>

<?php include '../includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Chapter</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f6fa;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .upload-chapter-container {
            max-width: 500px;
            margin: 40px auto 0 auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            padding: 2.5rem 2.2rem 2rem 2.2rem;
        }
        .upload-chapter-container h2 {
            text-align: center;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: #222;
        }
        .upload-chapter-container label {
            font-weight: 500;
            color: #333;
        }
        .upload-chapter-container input[type="text"],
        .upload-chapter-container input[type="number"],
        .upload-chapter-container input[type="file"] {
            width: 100%;
            padding: 0.6rem 0.8rem;
            margin-top: 0.2rem;
            margin-bottom: 1.2rem;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1rem;
            background: #f9f9f9;
            transition: border 0.2s;
        }
        .upload-chapter-container input[type="text"]:focus,
        .upload-chapter-container input[type="number"]:focus {
            border: 1.5px solid #007bff;
            outline: none;
            background: #fff;
        }
        .upload-chapter-container button[type="submit"] {
            background: #222;
            color: #fff;
            border: none;
            padding: 0.6rem 1.5rem;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
            width: 100%;
        }
        .upload-chapter-container button[type="submit"]:hover {
            background: #007bff;
        }
        .upload-chapter-container .alert {
            text-align: center;
            margin-bottom: 1.2rem;
            font-size: 1rem;
        }
    </style>
</head>
<body>    <div class="upload-chapter-container">
        <h2>Upload Chapter untuk: <?= htmlspecialchars($komik['judul']) ?></h2>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <label>Judul Chapter</label>
            <input type="text" name="judul" placeholder="Contoh: Chapter 1 - Awal Petualangan" 
                   value="<?= isset($_POST['judul']) ? htmlspecialchars($_POST['judul']) : '' ?>" required>

            <label>Urutan (contoh: 1, 2, 3...)</label>
            <input type="number" name="urutan" min="1" placeholder="1" 
                   value="<?= isset($_POST['urutan']) ? $_POST['urutan'] : '' ?>" required>

            <label>Gambar Chapter</label>
            <input type="file" name="file" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" required>
            <small style="color: #666; display: block; margin-top: -10px; margin-bottom: 15px;">
                Format yang didukung: JPG, JPEG, PNG, GIF, WEBP (Max: 2MB)
            </small>

            <button type="submit">Upload Chapter</button>
            
            <div style="text-align: center; margin-top: 15px;">
                <a href="../komik.php?id=<?= $komik_id ?>" style="color: #666; text-decoration: none;">
                    ← Kembali ke halaman komik
                </a>
            </div>
        </form>
    </div>
</body>
</html>