<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'author') {
    header("Location: ../index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style.css">
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT"
        crossorigin="anonymous" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet" />

    <style>
        .container {
            max-width: 1000px;
            margin: 40px auto;
            font-family: 'Poppins', sans-serif;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th {
            background-color: #3b82f6;
            color: white;
        }

        td,
        th {
            text-align: left;
            padding: 10px;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <?php
    include '../includes/koneksi.php';
    include '../includes/header.php';
    $user_id = $_SESSION['user_id'];
    $query = "SELECT * FROM komik WHERE user_id = $user_id ORDER BY created_at DESC";
    $result = mysqli_query($conn, $query);
    ?>
    ?>

    <div class="container">
        <h1>Dashboard Author</h1>

        <a href="upload-komik.php" class="btn btn-primary" style="margin-bottom: 20px;">+ Tambah Komik</a>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <table border="1" cellpadding="10" cellspacing="0" style="width:100%;">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Genre</th>
                        <th>Views</th>
                        <th>Cover</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['judul']) ?></td>
                            <td><?= htmlspecialchars($row['genre']) ?></td>
                            <td><?= $row['views'] ?></td>
                            <td><img src="../upload/<?= $row['cover'] ?>" width="80"></td>
                            <td>
                                <a href="edit-komik.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="hapus-komik.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin hapus komik ini?')" class="btn btn-danger btn-sm">Hapus</a>
                                <a href="upload-chapter.php?komik_id=<?= $row['id'] ?>" class="btn btn-success btn-sm mt-1">+ Chapter</a>
                            </td>

                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Belum ada komik yang kamu upload.</p>
        <?php endif; ?>
    </div>

    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
        crossorigin="anonymous"></script>

    <script src="js/script.js"></script>
</body>

</html>