<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'includes/koneksi.php';

$komik_id = isset($_GET['komik_id']) ? intval($_GET['komik_id']) : 0;
$urutan = isset($_GET['chapter']) ? intval($_GET['chapter']) : 1;

// Cek data komik & chapter
$komik = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM komik WHERE id = $komik_id"));
$chapter = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM chapter WHERE id_komik = $komik_id AND urutan = $urutan"));

if (!$komik || !$chapter) {
    echo "Chapter tidak ditemukan.";
    exit;
}

// Ambil total chapter
$max = mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(urutan) AS max FROM chapter WHERE id_komik = $komik_id"))['max'];
$min = mysqli_fetch_assoc(mysqli_query($conn, "SELECT MIN(urutan) AS min FROM chapter WHERE id_komik = $komik_id"))['min'];
?>

<?php include 'includes/header.php'; ?>
<div class="container" style="padding: 2rem;">
    <h2><?= htmlspecialchars($komik['judul']) ?> - <?= htmlspecialchars($chapter['judul']) ?></h2>
    <div style="text-align:center; margin: 20px 0;">
        <img src="upload/chapter/<?= htmlspecialchars($chapter['file']) ?>" style="max-width:100%; border-radius: 10px;">
    </div>

    <div class="navigation" style="text-align:center; margin-top: 30px;">
        <?php if ($urutan > $min): ?>
            <a href="chapter.php?komik_id=<?= $komik_id ?>&chapter=<?= $urutan - 1 ?>" class="btn btn-secondary">⏪ Sebelumnya</a>
        <?php endif; ?>
        <?php if ($urutan < $max): ?>
            <a href="chapter.php?komik_id=<?= $komik_id ?>&chapter=<?= $urutan + 1 ?>" class="btn btn-secondary">Selanjutnya ⏩</a>
        <?php endif; ?>
    </div>
</div>