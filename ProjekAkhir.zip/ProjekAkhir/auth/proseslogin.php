<?php
session_start();
include '../includes/koneksi.php';

$email = $_POST['email'];
$password = $_POST['password'];

$query = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
$user = mysqli_fetch_assoc($query);

if ($user) {
  if (password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_nama'] = $user['nama'];
    $_SESSION['user_role'] = $user['role'];

    // Arahkan sesuai role
    if ($user['role'] == 'pembaca') {
      header('Location: ../index.php');
    } elseif ($user['role'] == 'author') {
      header('Location: ../index.php');
    } elseif ($user['role'] == 'admin') {
      header('Location: ../index.php');
    }
    exit;
  } else {
    echo "<script>alert('Password salah!'); window.history.back();</script>";
  }
} else {
  echo "<script>alert('Email tidak ditemukan!'); window.history.back();</script>";
}
?>

