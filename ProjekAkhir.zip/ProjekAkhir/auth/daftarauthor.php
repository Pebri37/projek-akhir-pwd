<?php include '../includes/koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar Author</title>
</head>
<body>
  <h2>Daftar sebagai Author</h2>
  <form action="prosesdaftar.php" method="POST">
    <input type="hidden" name="role" value="author">
    <label>Nama:</label><br>
    <input type="text" name="nama" required><br>
    <label>Email:</label><br>
    <input type="email" name="email" required><br>
    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>
    <button type="submit">Daftar</button>
  </form>
</body>
</html>
