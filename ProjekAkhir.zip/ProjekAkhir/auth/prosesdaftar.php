<?php
include '../includes/koneksi.php';

$nama = $_POST['nama'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$role = $_POST['role'];

// Cek email udah ada atau belum
$cek = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
if (mysqli_num_rows($cek) > 0) {
  echo "<script>alert('Email sudah terdaftar!'); window.history.back();</script>";
  exit;
}

// Simpan ke database
$query = "INSERT INTO users (nama, email, password, role) VALUES ('$nama', '$email', '$password', '$role')";
if (mysqli_query($conn, $query)) {
  echo "<script>alert('Pendaftaran berhasil!'); window.location.href='../index.php';</script>";
} else {
  echo "<script>alert('Gagal daftar!'); window.history.back();</script>";
}
?>
